import cv2
import os
import random
import zipfile

# Parameters
source_file = "/Users/agi/Dropbox/_MAKE/_IG/Gen-3/_Gen-3_Alpha_H.mp4"
image_count = 35  # Number of images to extract per video
zip_output = False  # Set to True if you want to zip the output folder

# Get the folder of the source_file and append _frames
source_folder = os.path.dirname(source_file)
output_folder = os.path.join(
    source_folder, os.path.splitext(os.path.basename(source_file))[0] + "_frames"
)
os.makedirs(output_folder, exist_ok=True)


# Function to extract frames from a video file and save them as images
def extract_frames(video_path, image_count):
    vidcap = cv2.VideoCapture(video_path)
    vidcap.set(
        cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc("C", "Y", "U", "V")
    )  # Set the encoding
    total_frames = int(vidcap.get(cv2.CAP_PROP_FRAME_COUNT))

    if image_count > total_frames:
        print(
            f"Number of frames to extract is greater than the total frames in the video. Extracting {total_frames} frames instead."
        )
        image_count = total_frames

    if image_count == 0:
        print("No frames to extract.")
        return

    # Calculate a minimum distance between the frames
    min_distance = total_frames // image_count

    # Generate a list of frame numbers ensuring the minimum distance
    frames_to_extract = sorted(
        [
            random.randint(i * min_distance, (i + 1) * min_distance - 1)
            for i in range(image_count)
        ]
    )

    success, image = vidcap.read()
    count = 0
    while success:
        if count in frames_to_extract:
            # Save the image in uncompressed PNG format
            cv2.imwrite(os.path.join(output_folder, f"frame{count}.png"), image)
            frames_to_extract.remove(count)
        success, image = vidcap.read()
        count += 1

    return output_folder


# Function to zip the output folder
def zip_folder(output_folder):
    zipf = zipfile.ZipFile(f"{output_folder}.zip", "w", zipfile.ZIP_DEFLATED)
    for root, dirs, files in os.walk(output_folder):
        for file in files:
            zipf.write(
                os.path.join(root, file),
                os.path.relpath(
                    os.path.join(root, file), os.path.join(output_folder, "..")
                ),
            )
    zipf.close()


# Main function to process the videos
def main():
    # Process a single video file
    video_path = source_file
    print(f"Extracting frames from {video_path}...")
    output_subfolder = extract_frames(video_path, image_count)

    # Zip the output folder if zip_output is True
    if zip_output:
        zip_folder(output_subfolder)


if __name__ == "__main__":
    main()
